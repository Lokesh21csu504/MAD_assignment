
abstract class Playable {
  void play();
}