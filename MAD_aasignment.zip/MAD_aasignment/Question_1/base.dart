class base{
  String? playername;

  base(String player){
    this.playername = player;
  }

  void basefunc(String playername){
    print("Hello Player $playername");

  }

}